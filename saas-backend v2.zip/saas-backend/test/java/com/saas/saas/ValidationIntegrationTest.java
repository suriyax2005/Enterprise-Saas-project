package com.saas.saas;

import com.saas.saas.dto.CreateTenantRequest;
import com.saas.saas.dto.RegisterRequest;
import com.saas.saas.entity.User;
import com.saas.saas.repository.TenantRepository;
import com.saas.saas.repository.UserRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import java.util.Optional;

/**
 * Integration test suite for validation constraints (Module 2).
 * Verifies that custom validators (@EmailUnique, @PasswordStrength, @TenantExists)
 * and standard validations (@NotBlank, @NotNull) correctly trigger Bad Request validation payloads.
 */
@SpringBootTest
@AutoConfigureMockMvc
public class ValidationIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private UserRepository userRepository;

    @MockBean
    private TenantRepository tenantRepository;

    @BeforeEach
    public void setup() {
        // Setup mock checks for the validators
        Mockito.when(tenantRepository.existsById(1L)).thenReturn(true);
        Mockito.when(tenantRepository.existsById(999L)).thenReturn(false);

        Mockito.when(userRepository.findByEmail("taken@test.com")).thenReturn(Optional.of(new User()));
        Mockito.when(userRepository.findByEmail("available@test.com")).thenReturn(Optional.empty());
    }

    /**
     * Verifies that registering with a weak password triggers validation errors.
     */
    @Test
    public void testWeakPasswordValidation() throws Exception {
        RegisterRequest request = new RegisterRequest("Test User", "available@test.com", "weak", 1L);

        mockMvc.perform(MockMvcRequestBuilders.post("/v1/api/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(MockMvcResultMatchers.status().isBadRequest())
                .andExpect(MockMvcResultMatchers.jsonPath("$.validationErrors[0].field").value("password"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.validationErrors[0].message").value(
                        "Password must be at least 8 characters long, contain an uppercase letter, a lowercase letter, a digit, and a special character"
                ));
    }

    /**
     * Verifies that registering with an email already taken triggers uniqueness validation error.
     */
    @Test
    public void testDuplicateEmailValidation() throws Exception {
        RegisterRequest request = new RegisterRequest("Test User", "taken@test.com", "P@ssword123!", 1L);

        mockMvc.perform(MockMvcRequestBuilders.post("/v1/api/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(MockMvcResultMatchers.status().isBadRequest())
                .andExpect(MockMvcResultMatchers.jsonPath("$.validationErrors[0].field").value("email"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.validationErrors[0].message").value("Email address is already in use"));
    }

    /**
     * Verifies that registering with a non-existent tenant ID triggers validator failure.
     */
    @Test
    public void testNonExistentTenantValidation() throws Exception {
        RegisterRequest request = new RegisterRequest("Test User", "available@test.com", "P@ssword123!", 999L);

        mockMvc.perform(MockMvcRequestBuilders.post("/v1/api/auth/register")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(MockMvcResultMatchers.status().isBadRequest())
                .andExpect(MockMvcResultMatchers.jsonPath("$.validationErrors[0].field").value("tenantId"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.validationErrors[0].message").value("Specified tenant does not exist"));
    }

    /**
     * Verifies that creating a tenant with a blank name triggers @NotBlank validation error.
     */
    @Test
    public void testBlankTenantNameValidation() throws Exception {
        CreateTenantRequest request = new CreateTenantRequest("");

        mockMvc.perform(MockMvcRequestBuilders.post("/v1/api/tenant")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(MockMvcResultMatchers.status().isBadRequest())
                .andExpect(MockMvcResultMatchers.jsonPath("$.validationErrors[0].field").value("name"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.validationErrors[0].message").value("Tenant name required"));
    }
}
