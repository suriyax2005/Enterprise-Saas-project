package com.saas.saas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SaasApplicationTests {

	@Test
	void contextLoads() {
	}

}
