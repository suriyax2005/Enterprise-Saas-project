package com.saas.saas;

import com.saas.saas.dto.AuditDashboardResponse;
import com.saas.saas.dto.AuditLogResponse;
import com.saas.saas.entity.Tenant;
import com.saas.saas.entity.User;
import com.saas.saas.repository.UserRepository;
import com.saas.saas.security.JwtService;
import com.saas.saas.service.AuditLogService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.HashMap;
import java.util.Optional;

/**
 * Integration test suite for the Audit Controller.
 * Verifies security constraints (role verification), endpoint parameters, and export responses.
 */
@SpringBootTest
@AutoConfigureMockMvc
public class AuditControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private JwtService jwtService;

    @MockBean
    private AuditLogService auditLogService;

    @MockBean
    private UserRepository userRepository;

    private String adminToken;
    private String userToken;

    @BeforeEach
    public void setup() {
        Tenant tenant = new Tenant();
        tenant.setId(1L);
        tenant.setName("Test Tenant");

        User adminUser = new User();
        adminUser.setId(10L);
        adminUser.setEmail("admin@test.com");
        adminUser.setRole("ADMIN");
        adminUser.setTenant(tenant);

        User normalUser = new User();
        normalUser.setId(20L);
        normalUser.setEmail("user@test.com");
        normalUser.setRole("USER");
        normalUser.setTenant(tenant);

        // Mock repository responses for filter authentications
        Mockito.when(userRepository.findByEmail("admin@test.com")).thenReturn(Optional.of(adminUser));
        Mockito.when(userRepository.findByEmail("user@test.com")).thenReturn(Optional.of(normalUser));

        // Generate tokens
        adminToken = "Bearer " + jwtService.generateToken("admin@test.com", 1L);
        userToken = "Bearer " + jwtService.generateToken("user@test.com", 1L);
    }

    /**
     * Verifies that requests without Authorization headers return 403 Forbidden
     * because of security requestMatchers rule defaults.
     */
    @Test
    public void testGetLogsUnauthenticated() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/v1/api/audit/logs"))
                .andExpect(MockMvcResultMatchers.status().isForbidden());
    }

    /**
     * Verifies that normal USER role results in 403 Forbidden access to audit logs.
     */
    @Test
    public void testGetLogsAsUserForbidden() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/v1/api/audit/logs")
                        .header(HttpHeaders.AUTHORIZATION, userToken))
                .andExpect(MockMvcResultMatchers.status().isForbidden());
    }

    /**
     * Verifies that ADMIN role allows successful fetching of audit logs.
     */
    @Test
    public void testGetLogsAsAdminSuccess() throws Exception {
        Mockito.when(auditLogService.getLogs(
                Mockito.eq(1L), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(Pageable.class)
        )).thenReturn(new PageImpl<>(Collections.emptyList()));

        mockMvc.perform(MockMvcRequestBuilders.get("/v1/api/audit/logs")
                        .header(HttpHeaders.AUTHORIZATION, adminToken)
                        .param("page", "0")
                        .param("size", "10"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.content").isArray());
    }

    /**
     * Verifies that ADMIN role can access the audit dashboard stats.
     */
    @Test
    public void testGetDashboardSuccess() throws Exception {
        AuditDashboardResponse stats = new AuditDashboardResponse(
                100, 90, 10, new HashMap<>(), Collections.emptyList()
        );
        Mockito.when(auditLogService.getDashboardStats(1L)).thenReturn(stats);

        mockMvc.perform(MockMvcRequestBuilders.get("/v1/api/audit/dashboard")
                        .header(HttpHeaders.AUTHORIZATION, adminToken))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.totalLogs").value(100))
                .andExpect(MockMvcResultMatchers.jsonPath("$.successLogs").value(90))
                .andExpect(MockMvcResultMatchers.jsonPath("$.failureLogs").value(10));
    }

    /**
     * Verifies CSV export response content headers.
     */
    @Test
    public void testExportCsvSuccess() throws Exception {
        byte[] csvBytes = "ID,Action\n1,LOGIN".getBytes();
        Mockito.when(auditLogService.exportToCsv(
                Mockito.eq(1L), Mockito.any(), Mockito.any(), Mockito.any(), Mockito.any(),
                Mockito.any(), Mockito.any(), Mockito.any()
        )).thenReturn(csvBytes);

        mockMvc.perform(MockMvcRequestBuilders.get("/v1/api/audit/export/csv")
                        .header(HttpHeaders.AUTHORIZATION, adminToken))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.header().string(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"audit_logs.csv\""))
                .andExpect(MockMvcResultMatchers.content().contentType("text/csv"))
                .andExpect(MockMvcResultMatchers.content().bytes(csvBytes));
    }
}
