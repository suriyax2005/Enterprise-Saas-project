package com.saas.saas;

import com.saas.saas.dto.LoginRequest;
import com.saas.saas.entity.BlacklistedToken;
import com.saas.saas.entity.Tenant;
import com.saas.saas.entity.User;
import com.saas.saas.repository.BlacklistedTokenRepository;
import com.saas.saas.repository.UserRepository;
import com.saas.saas.security.JwtService;
import com.saas.saas.security.RateLimitingFilter;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import java.time.LocalDateTime;
import java.util.Optional;

/**
 * Integration test suite for security hardening controls (Module 3).
 * Verifies Rate Limiting limits, Account Lockouts after failed attempts, and JWT Blacklist checking.
 */
@SpringBootTest
@AutoConfigureMockMvc
public class SecurityHardeningIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private RateLimitingFilter rateLimitingFilter;

    @MockBean
    private UserRepository userRepository;

    @MockBean
    private BlacklistedTokenRepository blacklistedTokenRepository;

    private User testUser;
    private String adminToken;

    @BeforeEach
    public void setup() {
        rateLimitingFilter.clearLimits();

        Tenant tenant = new Tenant();
        tenant.setId(1L);
        tenant.setName("Hardened Tenant");

        testUser = new User();
        testUser.setId(101L);
        testUser.setName("Security User");
        testUser.setEmail("secure@test.com");
        testUser.setPassword(passwordEncoder.encode("SecureP@ss123"));
        testUser.setRole("ADMIN");
        testUser.setTenant(tenant);
        testUser.setEmailVerified(true);
        testUser.setFailedLoginAttempts(0);
        testUser.setAccountLocked(false);

        Mockito.when(userRepository.findByEmail("secure@test.com")).thenReturn(Optional.of(testUser));
        adminToken = "Bearer " + jwtService.generateToken("secure@test.com", 1L);
    }

    /**
     * Verifies that rate limiting yields HTTP 429 Too Many Requests when hitting login endpoint repeatedly.
     */
    @Test
    public void testRateLimitingOnLogin() throws Exception {
        LoginRequest loginRequest = new LoginRequest();
        loginRequest.setEmail("secure@test.com");
        loginRequest.setPassword("wrong-password");

        // The threshold is 5 login requests per minute. Let's make 6 requests.
        for (int i = 0; i < 5; i++) {
            mockMvc.perform(MockMvcRequestBuilders.post("/v1/api/auth/login")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(loginRequest)))
                    .andExpect(MockMvcResultMatchers.status().isBadRequest()); // Wrong password error
        }

        // The 6th request should trigger HTTP 429 Too Many Requests
        mockMvc.perform(MockMvcRequestBuilders.post("/v1/api/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(loginRequest)))
                .andExpect(MockMvcResultMatchers.status().isTooManyRequests())
                .andExpect(MockMvcResultMatchers.jsonPath("$.status").value(429))
                .andExpect(MockMvcResultMatchers.jsonPath("$.message").value(
                        "Login attempt rate limit exceeded. Please wait a minute and try again."
                ));
    }

    /**
     * Verifies that 5 failed attempts locks the user account.
     */
    @Test
    public void testAccountLockoutFlow() throws Exception {
        LoginRequest loginRequest = new LoginRequest();
        loginRequest.setEmail("secure@test.com");
        loginRequest.setPassword("wrong-password");

        // Execute login failures.
        // We bypass rate limiting filter in this test context by resetting its state if needed, or by testing
        // the lockout counter directly at the service level.
        // Let's assert on the counter transitions of the testUser object modified by the service.
        for (int i = 1; i <= 5; i++) {
            mockMvc.perform(MockMvcRequestBuilders.post("/v1/api/auth/login")
                            .contentType(MediaType.APPLICATION_JSON)
                            .content(objectMapper.writeValueAsString(loginRequest)))
                    .andExpect(MockMvcResultMatchers.status().isBadRequest());
        }

        // The user account must transition to locked
        org.junit.jupiter.api.Assertions.assertTrue(testUser.isAccountLocked());
        org.junit.jupiter.api.Assertions.assertNotNull(testUser.getLockTime());
    }

    /**
     * Verifies that requests with a blacklisted access token are blocked (returns 403 or runs filter bypass).
     * Since blacklist filter returns 200/403/401 depending on path mappings, let's verify it blocks filter chain.
     */
    @Test
    public void testJwtBlacklistBlocking() throws Exception {
        String tokenString = adminToken.substring(7);
        Mockito.when(blacklistedTokenRepository.existsByToken(tokenString)).thenReturn(true);

        mockMvc.perform(MockMvcRequestBuilders.get("/v1/api/audit/logs")
                        .header(HttpHeaders.AUTHORIZATION, adminToken))
                .andExpect(MockMvcResultMatchers.status().isForbidden()); // Filter halts authentication so requests are forbidden
    }
}
