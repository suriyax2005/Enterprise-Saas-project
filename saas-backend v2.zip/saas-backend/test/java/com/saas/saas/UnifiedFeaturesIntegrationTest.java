package com.saas.saas;

import com.saas.saas.dto.CreateTenantRequest;
import com.saas.saas.dto.TenantResponse;
import com.saas.saas.entity.Notification;
import com.saas.saas.entity.Tenant;
import com.saas.saas.entity.User;
import com.saas.saas.repository.NotificationRepository;
import com.saas.saas.repository.TenantRepository;
import com.saas.saas.repository.UserRepository;
import com.saas.saas.security.JwtService;
import com.saas.saas.service.NotificationService;
import com.saas.saas.service.TenantService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cache.CacheManager;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.transaction.annotation.Transactional;

import java.util.Objects;
import java.util.Optional;

/**
 * Integration test suite for the remaining SaaS features:
 * Caching, File Upload, In-app Notifications, User directory searches, Actuator health metrics, and Swagger docs.
 */
@SpringBootTest
@AutoConfigureMockMvc
public class UnifiedFeaturesIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private TenantService tenantService;

    @Autowired
    private TenantRepository tenantRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private NotificationService notificationService;

    @Autowired
    private NotificationRepository notificationRepository;

    @Autowired
    private CacheManager cacheManager;

    private User adminUser;
    private String adminToken;

    @BeforeEach
    public void setup() {
        // Evict caching before test runs
        Objects.requireNonNull(cacheManager.getCache("tenants")).clear();

        // Ensure we have a valid tenant in DB
        Tenant tenant = tenantRepository.findByName("Unified Tenant")
                .orElseGet(() -> {
                    Tenant t = new Tenant();
                    t.setName("Unified Tenant");
                    return tenantRepository.save(t);
                });

        // Ensure we have an admin user in DB
        adminUser = userRepository.findByEmail("admin@unified.com")
                .orElseGet(() -> {
                    User u = new User();
                    u.setName("Unified Admin");
                    u.setEmail("admin@unified.com");
                    u.setPassword("encodedPassword123");
                    u.setRole("ADMIN");
                    u.setTenant(tenant);
                    u.setEmailVerified(true);
                    return userRepository.save(u);
                });

        adminToken = "Bearer " + jwtService.generateToken(adminUser.getEmail(), tenant.getId());
    }

    /**
     * Verifies that tenant retrieval uses the cache.
     */
    @Test
    public void testTenantCaching() {
        // 1. Create a tenant
        CreateTenantRequest request = new CreateTenantRequest();
        request.setName("Cached Tenant Inc");
        TenantResponse created = tenantService.createTenant(request);

        // 2. Query once to load it into cache
        TenantResponse firstQuery = tenantService.getTenantById(created.getId());
        Assertions.assertNotNull(firstQuery);
        Assertions.assertEquals("Cached Tenant Inc", firstQuery.getName());

        // 3. Delete the tenant directly from the database repository (bypassing eviction)
        tenantRepository.deleteById(created.getId());

        // 4. Query again - should return the cached response even though database record is gone!
        TenantResponse secondQuery = tenantService.getTenantById(created.getId());
        Assertions.assertNotNull(secondQuery);
        Assertions.assertEquals("Cached Tenant Inc", secondQuery.getName());
    }

    /**
     * Verifies profile image uploads accept correct types and reject invalid types.
     */
    @Test
    public void testFileUploadMimeTypes() throws Exception {
        MockMultipartFile validImageFile = new MockMultipartFile(
                "file",
                "avatar.png",
                "image/png",
                "fake image contents".getBytes()
        );

        MockMultipartFile invalidExeFile = new MockMultipartFile(
                "file",
                "virus.exe",
                "application/x-msdownload",
                "malicious code payload".getBytes()
        );

        // Valid image upload should succeed
        mockMvc.perform(MockMvcRequestBuilders.multipart("/v1/api/files/upload")
                        .file(validImageFile)
                        .header(HttpHeaders.AUTHORIZATION, adminToken))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.status").value("success"));

        // Executable file upload should be blocked
        mockMvc.perform(MockMvcRequestBuilders.multipart("/v1/api/files/upload")
                        .file(invalidExeFile)
                        .header(HttpHeaders.AUTHORIZATION, adminToken))
                .andExpect(MockMvcResultMatchers.status().isBadRequest()); // Invalid file type rejected with 400
    }

    /**
     * Verifies in-app notification count and read acknowledge actions.
     */
    @Test
    @Transactional
    public void testNotificationFlow() throws Exception {
        // 1. Dispatch a test notification
        Notification notification = notificationService.createNotification(adminUser, "Security configuration changed", "IN_APP");
        Assertions.assertNotNull(notification.getId());

        // 2. Verify GET list returns it
        mockMvc.perform(MockMvcRequestBuilders.get("/v1/api/notifications")
                        .header(HttpHeaders.AUTHORIZATION, adminToken))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$[0].message").value("Security configuration changed"));

        // 3. Verify unread count is 1
        mockMvc.perform(MockMvcRequestBuilders.get("/v1/api/notifications/unread-count")
                        .header(HttpHeaders.AUTHORIZATION, adminToken))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.unreadCount").value(1));

        // 4. Mark as read
        mockMvc.perform(MockMvcRequestBuilders.put("/v1/api/notifications/read/" + notification.getId())
                        .header(HttpHeaders.AUTHORIZATION, adminToken))
                .andExpect(MockMvcResultMatchers.status().isOk());

        // 5. Verify unread count decreases to 0
        mockMvc.perform(MockMvcRequestBuilders.get("/v1/api/notifications/unread-count")
                        .header(HttpHeaders.AUTHORIZATION, adminToken))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.unreadCount").value(0));
    }

    /**
     * Verifies the specifications-driven search query endpoint.
     */
    @Test
    public void testAdminUserDynamicSearch() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/v1/api/admin/users/search")
                        .param("name", "Unified")
                        .param("role", "ADMIN")
                        .header(HttpHeaders.AUTHORIZATION, adminToken))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.content[0].email").value("admin@unified.com"));
    }

    /**
     * Verifies Actuator endpoint health check outputs.
     */
    @Test
    public void testActuatorHealth() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/actuator/health"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.status").value("UP"));
    }

    /**
     * Verifies Swagger API Docs generation.
     */
    @Test
    public void testSwaggerApiDocs() throws Exception {
        mockMvc.perform(MockMvcRequestBuilders.get("/v3/api-docs"))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andExpect(MockMvcResultMatchers.jsonPath("$.openapi").exists());
    }
}
